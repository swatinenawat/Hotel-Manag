package com.cg.hms.dto;
public class User 
{
	private int  user_id;
	private String	password;
	private String	role;
	private String	user_name;
	private String	mob_no;
	private String	phone;
	private String	address;
	private String	email;
		
	public User() 
	{
			
	}
	
	public User(int user_id, String password, String role, String user_name, String mob_no, String phone,
				String address, String email) 
	{
			
			this.user_id = user_id;
			this.password = password;
			this.role = role;
			this.user_name = user_name;
			this.mob_no = mob_no;
			this.phone = phone;
			this.address = address;
			this.email = email;
	}
	
	public int getUser_id()
	{
			return user_id;
	}
		
	public void setUser_id(int user_id) 
	{
			this.user_id = user_id;
	}
	
	public String getPassword() 
	{
			return password;
	}
	
	public void setPassword(String password) 
	{
			this.password = password;
	}
	
	public String getRole() 
	{
			return role;
	}
	
	public void setRole(String role) 
	{
			this.role = role;
	}
		
	public String getUser_name() 
	{
			return user_name;
	}
	
	public void setUser_name(String user_name) 
	{
			this.user_name = user_name;
	}
		
	public String getMob_no() 
	{
			return mob_no;
		
	}
		
	public void setMob_no(String mob_no)
	{
			this.mob_no = mob_no;
	}
		
	public String getPhone()
	{
			return phone;
		
	}
		
	public void setPhone(String phone) 
	{
			this.phone = phone;
	}
	
	public String getAddress()
	{
			return address;
	}
	
	public void setAddress(String address)
	{
			this.address = address;
	}
	
	public String getEmail() 
	{
			return email;
		
	}
		
	public void setEmail(String email) 
	{
			this.email = email;
		
	}
	
	@Override
	public String toString() 
	{
			return "User [user_id=" + user_id + ", password=" + password + ", role=" + role + ", user_name=" + user_name
					+ ", mob_no=" + mob_no + ", phone=" + phone + ", address=" + address + ", email=" + email + "]";
	}
		
	
	}
