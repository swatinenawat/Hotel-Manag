package com.cg.hms.ui;

import java.util.Scanner;

import com.cg.hms.dto.User;
import com.cg.hms.exception.HotelBookingException;
import com.cg.hms.service.HotelBookingServiceImpl;

public class HotelBookingMain 
{
	
	
	 static Scanner sc=new Scanner(System.in);
	 static HotelBookingServiceImpl hbs=null;
	
	public static void main(String args[])
	{
	
		int choice;
		while(true)
		{
			 System.out.println("1: Register\t2: Login \t3: Exit");
			 System.out.println("Enter your choice");
			 choice=sc.nextInt();
			 switch(choice)
			 {
			 	case 1: registerUser();break;
			 	case 2: loginUser();break;
			 	default: System.exit(0);
			 }
			 
		}
	}
	public static void registerUser()
	{
		
		hbs=new HotelBookingServiceImpl();
		int userId;
		String	u_password;
		String	u_role;
		String	u_name;
		String	u_mobno;
		String	u_phone;
		String	u_address;
		String	u_email;
		System.out.println("Enter user details");
		System.out.println("Enter User Name");
		u_name=sc.next();
		System.out.println("Enter Password");
		u_password=sc.next();
		System.out.println("Enter User Role");
		u_role=sc.next();
		System.out.println("Enter User Mobile no");
		u_mobno=sc.next();
		System.out.println("Enter User Phone no");
		u_phone=sc.next();
		System.out.println("Enter User Address");
		u_address=sc.next();
		System.out.println("Enter User Email");
		u_email=sc.next();
		User u=new User(0,u_password,u_role,u_name,u_mobno,u_phone,u_address,u_email);
		try 
		{
			userId=hbs.register(u);
			if(userId!=0)
			{
				System.out.println("Your uid is "+userId);
			}
		} 
		catch (HotelBookingException e) 
		{
			System.out.println(e);
		}
		
	}
	
	public static void loginUser()
	{
		
		hbs=new HotelBookingServiceImpl();
		int userId;
		int log=0;
		String	u_password;
		System.out.println("Enter User Id");
		userId=sc.nextInt();
		System.out.println("Enter Password");
		u_password=sc.next();
		try 
		{
			log=hbs.login(userId,u_password);
			if(log==1)
				System.out.println("Successfully Login");
	    
		    
		
		} 
		catch (HotelBookingException e) 
		{
			System.out.println(e);
		}
		
	}

}
