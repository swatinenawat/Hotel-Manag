package com.cg.hms.ui;

import java.util.Scanner;

import com.cg.hms.dto.User;
import com.cg.hms.exception.HotelBookingException;
import com.cg.hms.service.HotelBookingServiceImpl;

public class HotelBookingMain 
{
	
	
	 static Scanner sc=new Scanner(System.in);
	 static HotelBookingServiceImpl hbs=null;
	
	public static void main(String args[])
	{
	
		int role;
		System.out.println("1:Admin\t2:User");
		System.out.println("Enter your choice");
		role=sc.nextInt();
		
		if(role==1)
		{
			adminDisplay();
		}
		else
		{
			userDisplay();
		}
		
		
	}
	
	public static void registerUser()
	{
		
		hbs=new HotelBookingServiceImpl();
		int userId;
		String	u_password;
		String	u_role;
		String	u_name;
		String	u_mobno;
		String	u_phone;
		String	u_address;
		String	u_email;
		System.out.println("Enter user details");
		System.out.println("Enter User Name");
		u_name=sc.next();
		System.out.println("Enter Password");
		u_password=sc.next();
		System.out.println("Enter User Role");
		u_role=sc.next();
		System.out.println("Enter User Mobile no");
		u_mobno=sc.next();
		System.out.println("Enter User Phone no");
		u_phone=sc.next();
		System.out.println("Enter User Address");
		u_address=sc.next();
		System.out.println("Enter User Email");
		u_email=sc.next();
		User u=new User(0,u_password,u_role,u_name,u_mobno,u_phone,u_address,u_email);
		try 
		{
			userId=hbs.register(u);
			if(userId!=0)
			{
				System.out.println("Your uid is "+userId);
				loginUser();
			}
		} 
		catch (HotelBookingException e) 
		{
			System.out.println(e);
		}
		
	}
	
	public static void loginUser()
	{
		
		hbs=new HotelBookingServiceImpl();
		int userId;
		String log="";
		String	u_password;
		System.out.println("Enter User Id");
		userId=sc.nextInt();
		System.out.println("Enter Password");
		u_password=sc.next();
		try 
		{
			log=hbs.login(0,userId,u_password);
			
			System.out.println("Welcome "+log);
			while(true)
			 {
				 System.out.println("1:Search Hotel");
				 System.out.println("2:Book Hotel");
				 System.out.println("3:View Booking Details");
				 System.out.println("4:Exit");
				 System.out.println("Enter your choice");
				 int choice=sc.nextInt();
				 
				 switch(choice)
				 {
				 	case 1:searchHotel();
				 	case 2:
				 	case 3:
				 	default:System.exit(0);
				 }
			 }
			 
		    
		
		} 
		catch (HotelBookingException e) 
		{
			System.out.println(e);
		}
		
	}
	
	
	
	public static void adminDisplay()
	{
		
		hbs=new HotelBookingServiceImpl();
		int choice,adminId;
		String password;
		System.out.print("Enter login Id : ");
		adminId=sc.nextInt();
		System.out.println("");
		System.out.print("Enter login password : ");
		password=sc.next();
		System.out.println("");
		try 
		{
			 String logName=hbs.login(1,adminId, password);
			 System.out.println("Welcome "+logName);
			 while(true)
			 {
				 System.out.println("1:Add Hotel");
				 System.out.println("2:Delete Hotel");
				 System.out.println("3:Modify Hotel");
				 System.out.println("4:Add Room");
				 System.out.println("5:Delete Room");
				 System.out.println("6:Modify Room");
				 System.out.println("7:Generate Report");
				 System.out.println("8:Exit");
				 System.out.println("Enter your choice");
				 choice=sc.nextInt();
				 
				 switch(choice)
				 {
				 	case 1:
				 	case 2:
				 	case 3:
				 	case 4:
				 	case 5:
				 	case 6:
				 	case 7:
				 	default:System.exit(0);
				 }
			 }
			 
	
		} 
		catch (HotelBookingException e) 
		{
			e.printStackTrace();
		}
		
		
	}

	public static void userDisplay()
	{
		
		int choice;
		while(true)
		{
			System.out.println("1:Register");
			System.out.println("2:login");
			System.out.println("3:Exit");
		    System.out.println("Enter your choice");
			choice=sc.nextInt();
				 
			switch(choice)
			{
				case 1:registerUser();
				case 2:loginUser();
				default:System.exit(0);
			}
		}
			
	}
	
	public static void searchHotel()
	{
		
	}
}
