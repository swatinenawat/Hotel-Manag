package com.cg.hms.util;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;
import java.sql.SQLException;

public class DBUtil {
	static String driver=null;
	static String url=null;
	static String unm=null;
	static String pwd=null;
	
	public static Connection getConn() throws IOException,SQLException
{
Properties myProps=loadDBInfo();
driver=myProps.getProperty("dbDriver");
url=myProps.getProperty("dbUrl");
unm=myProps.getProperty("dbUser");
pwd=myProps.getProperty("dbPassword");
Connection con=null;
if(con==null)
   {
	con=DriverManager.getConnection(url,unm,pwd);
	return con;
   }
else
	return con;
}
	
	
public static Properties loadDBInfo() throws IOException
{
	FileReader fr=new FileReader("DBUtil.properties");
	Properties dbProps=new Properties();
	dbProps.load(fr);//to load all db info from properties file
    return dbProps;

}


}

