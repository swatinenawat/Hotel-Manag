package com.cg.hms.service;

import java.util.ArrayList;
import java.util.Date;

import com.cg.hms.dao.HotelBookingDaoImpl;
import com.cg.hms.dto.BookingDetails;
import com.cg.hms.dto.Hotel;
import com.cg.hms.dto.RoomDetails;
import com.cg.hms.dto.User;
import com.cg.hms.exception.HotelBookingException;

public class HotelBookingServiceImpl implements HotelBookingService 
{
	HotelBookingDaoImpl hbdao=null;
	public HotelBookingServiceImpl() 
	{
		 hbdao=new HotelBookingDaoImpl(); 
	}

	@Override
	public int register(User user) throws HotelBookingException 
	{
		return hbdao.register(user);
	}

	@Override
	public String login(int role,int userId, String password) throws HotelBookingException 
	{
			return hbdao.login(role,userId, password);
	}

	@Override
	public int addHotel(Hotel hotel) throws HotelBookingException 
	{
		return hbdao.addHotel(hotel);
	}

	@Override
	public int modifyHotel(Hotel hotel) throws HotelBookingException 
	{
		// TODO Auto-generated method stub
		return hbdao.modifyHotel(hotel);
	}

	@Override
	public int deleteHotel(int hotel_id) throws HotelBookingException 
	{
		// TODO Auto-generated method stub
		return hbdao.deleteHotel(hotel_id);
	}

	@Override
	public int addRoom(RoomDetails room) throws HotelBookingException 
	{
		// TODO Auto-generated method stub
		return hbdao.addRoom(room);
	}

	@Override
	public int modifyRoom(RoomDetails room) throws HotelBookingException 
	{
		// TODO Auto-generated method stub
		return hbdao.modifyRoom(room);
	}

	@Override
	public int deleteRoom(int room_id) throws HotelBookingException 
	{
		// TODO Auto-generated method stub
		return hbdao.deleteRoom(room_id);
	}

	@Override
	public String bookRoom(BookingDetails bookingDetails)
			throws HotelBookingException 
	{
		// TODO Auto-generated method stub
		return hbdao.bookRoom(bookingDetails);
	}

	@Override
	public BookingDetails viewBookingStatus(int bookingId)
			throws HotelBookingException 
	{
		// TODO Auto-generated method stub
		return hbdao.viewBookingStatus(bookingId);
	}

	@Override
	public ArrayList<RoomDetails> searchRoom(int hotelId)
			throws HotelBookingException
			{
		// TODO Auto-generated method stub
		return hbdao.searchRoom(hotelId);
	}

	@Override
	public ArrayList<Hotel> displayHotels() throws HotelBookingException 
	{
		// TODO Auto-generated method stub
		return hbdao.displayHotels();
	}

	@Override
	public ArrayList<BookingDetails> viewBookingByHotel(int hotelId)
			throws HotelBookingException 
			{
		// TODO Auto-generated method stub
		return hbdao.viewBookingByHotel(hotelId);
	}

	@Override
	public ArrayList<BookingDetails> viewGuestListOfHotel(int hotelId)
			throws HotelBookingException {
		// TODO Auto-generated method stub
		return hbdao.viewGuestListOfHotel(hotelId);
	}

	@Override
	public ArrayList<BookingDetails> viewBookingByDate(Date date)
			throws HotelBookingException {
		// TODO Auto-generated method stub
		return hbdao.viewBookingByDate(date);
	}

	
}
