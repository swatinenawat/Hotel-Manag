package com.cg.hms.service;

import com.cg.hms.dao.HotelBookingDaoImpl;
import com.cg.hms.dto.Hotel;
import com.cg.hms.dto.User;
import com.cg.hms.exception.HotelBookingException;

public class HotelBookingServiceImpl implements HotelBookingService 
{
	HotelBookingDaoImpl hbdao=null;
	public HotelBookingServiceImpl() 
	{
		 hbdao=new HotelBookingDaoImpl(); 
	}

	@Override
	public int register(User user) throws HotelBookingException 
	{
		return hbdao.register(user);
	}

	@Override
	public int login(int userId, String password) throws HotelBookingException 
	{
			return hbdao.login(userId, password);
	}

	@Override
	public int addHotel(Hotel hotel) throws HotelBookingException 
	{
		return 0;
	}

	
	
}
