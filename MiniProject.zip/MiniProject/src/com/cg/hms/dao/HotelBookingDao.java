package com.cg.hms.dao;

import com.cg.hms.dto.Hotel;
import com.cg.hms.dto.User;
import com.cg.hms.exception.HotelBookingException;

public interface HotelBookingDao 
{

	public int register(User user)throws HotelBookingException;
	public int login(int user_id,String password)throws HotelBookingException;
	public int addHotel(Hotel hotel)throws HotelBookingException;
	
	
}
