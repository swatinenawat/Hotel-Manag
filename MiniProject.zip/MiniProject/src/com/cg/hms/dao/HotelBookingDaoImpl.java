package com.cg.hms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cg.hms.dto.Hotel;
import com.cg.hms.dto.User;
import com.cg.hms.exception.HotelBookingException;
import com.cg.hms.util.DBUtil;

public class HotelBookingDaoImpl implements HotelBookingDao 
{
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;

	@Override
	public int register(User user) throws HotelBookingException 
	{
		
        int uid=0;
		try 
		{
			con=DBUtil.getConn();
			String seqid="select seq_user_id.nextVal from dual";
			st=con.createStatement();
			rs=st.executeQuery(seqid);
			while(rs.next())	
			{
				uid=rs.getInt(1);	
			}
			String insertqry="INSERT into Users values(?,?,?,?,?,?,?,?)";
	
			pst=con.prepareStatement(insertqry);
			pst.setInt(1,uid);
			pst.setString(2,user.getPassword());
			pst.setString(3,user.getRole());
			pst.setString(4,user.getUser_name());
			pst.setString(5,user.getMob_no());
			pst.setString(6,user.getPhone());
			pst.setString(7,user.getAddress());
			pst.setString(8,user.getEmail());
	
			
		}
		catch(Exception e)
		{
			throw new HotelBookingException(e.getMessage());
		}
		return uid;
		
		
		
	}

	@Override
	public int login(int userId, String password) throws HotelBookingException 
	{
		String userPass="";
		try 
		{
			String query="SELECT password FROM USERS WHERE user_id=?";
			pst=con.prepareStatement(query);
			pst.setInt(1,userId);
			rs=pst.executeQuery();
			while(rs.next())
			{
				userPass=rs.getString(0);
				System.out.println(userPass);
			}
			if(userPass.equals(""))
				throw new HotelBookingException("Invalid user ID");
			else
			{
				if(userPass.equals(password))
					//return 1;
					System.out.println("Done");
				else
					throw new HotelBookingException("Password incorrect");
			
		    }
		
		}  
		catch (Exception e)
		{
			
			throw new HotelBookingException("Invalid UserID or Password");  
		}
		
		
	}

	@Override
	public int addHotel(Hotel hotel) throws HotelBookingException
	{
		// TODO Auto-generated method stub
		return 0;
	}
	
	

}
