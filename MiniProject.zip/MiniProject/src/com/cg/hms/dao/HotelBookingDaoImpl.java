package com.cg.hms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;

import com.cg.hms.dto.BookingDetails;
import com.cg.hms.dto.Hotel;
import com.cg.hms.dto.RoomDetails;
import com.cg.hms.dto.User;
import com.cg.hms.exception.HotelBookingException;
import com.cg.hms.util.DBUtil;

public class HotelBookingDaoImpl implements HotelBookingDao 
{
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;

	@Override
	public int register(User user) throws HotelBookingException 
	{
		
        int uid=0;
		try 
		{
			con=DBUtil.getConn();
			String seqid="select seq_user_id.nextVal from dual";
			st=con.createStatement();
			rs=st.executeQuery(seqid);
			while(rs.next())	
			{
				uid=rs.getInt(1);	
			}
			String insertqry="INSERT into Users values(?,?,?,?,?,?,?,?)";
	
			pst=con.prepareStatement(insertqry);
			pst.setInt(1,uid);
			pst.setString(2,user.getPassword());
			pst.setString(3,user.getRole());
			pst.setString(4,user.getUser_name());
			pst.setString(5,user.getMob_no());
			pst.setString(6,user.getPhone());
			pst.setString(7,user.getAddress());
			pst.setString(8,user.getEmail());
			pst.execute();
		}
		catch(Exception e)
		{
			throw new HotelBookingException(e.getMessage());
		}
		return uid;
		
		
		
	}

	@Override
	public String login(int role,int userId, String password) throws HotelBookingException 
	{
		
		String userPass="",username="";
		int userRole=0;
		try 
		{
			con=DBUtil.getConn();
			String query="SELECT * FROM USERS WHERE user_id=?";
			pst=con.prepareStatement(query);
			pst.setInt(1,userId);
			rs=pst.executeQuery();
			while(rs.next())
			{
				userPass=rs.getString("password");
				username=rs.getString("user_name");
				if(rs.getString("role").equals("Admin"))
					userRole=1;
			}
			if(userPass.equals(""))
				throw new HotelBookingException("Invalid user ID");
			else
			{
				if(userPass.equals(password))
				{
					if(role==userRole)
						return username;
					else
						throw new HotelBookingException("Password incorrect");
				}
					
					
				else
					throw new HotelBookingException("Password incorrect");
			
		    }
		
		}  
		catch (Exception e)
		{
			e.printStackTrace();
			throw new HotelBookingException("Invalid UserID or Password");  
		}
		
	
	}

	@Override
	public int addHotel(Hotel hotel) throws HotelBookingException
	{
		
		return 0;
	}

	@Override
	public int modifyHotel(Hotel hotel) throws HotelBookingException {
		
		
		
		
		return 0;
	}

	@Override
	public int deleteHotel(int hotel_id) throws HotelBookingException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int addRoom(RoomDetails room) throws HotelBookingException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int modifyRoom(RoomDetails room) throws HotelBookingException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deleteRoom(int room_id) throws HotelBookingException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String bookRoom(BookingDetails bookingDetails)
			throws HotelBookingException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public BookingDetails viewBookingStatus(int bookingId)
			throws HotelBookingException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<RoomDetails> searchRoom(int hotelId)
			throws HotelBookingException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<Hotel> displayHotels() throws HotelBookingException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<BookingDetails> viewBookingByHotel(int hotelId)
			throws HotelBookingException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<BookingDetails> viewGuestListOfHotel(int hotelId)
			throws HotelBookingException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<BookingDetails> viewBookingByDate(Date date)
			throws HotelBookingException {
		// TODO Auto-generated method stub
		return null;
	}

	
	

}
